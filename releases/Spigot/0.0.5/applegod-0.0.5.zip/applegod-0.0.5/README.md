# AppleGOD
Version 0.0.5  |  Spigot 1.16.1



Spigot plugin
https://www.spigotmc.org/resources/applegod.68729/

Minecraft Vanilla 1.8.1
https://minecraft.curseforge.com/projects/applegod


## Information & how to's
Just a mod to make apples. Instead of going to a mine/farming.
It combines the fun of crafting and not getting the apple for free. The apples are craftable from within the servers recipes, therefore you can see how an apple is crafted. Now no more worries about finding apples.

I will update the plugin when needed. Feel free to join the Discord server.
https://discord.gg/n4AQVS8

### Crafting an apple
![image of crafting an apple](https://tacaly.com/wp-content/uploads/2019/06/craft-in-system.png)

